#include "engine.h"

int main()
{
	engine_t engine;
	engine.start();

	return 0;
}
