#pragma once

#include "board.h"

int evaluate(const board_t& board);
